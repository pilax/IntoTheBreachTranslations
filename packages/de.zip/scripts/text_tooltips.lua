
TILE_TOOLTIPS = {
	fire = {"Feuer", "Steckt Einheiten in Brand."},
	forest = {"Wald", "Wenn er besch�digt wird, brennt er."},
	forest_fire = {"Waldbrand", "Setzt Einheiten in Brand. Dieses Feuer wurde durch einen besch�digten Wald entfacht."},
	smoke = {"Rauch", "Einheiten im Rauch k�nnen weder angreifen noch reparieren."},
	electric_smoke = {"Elektrischer Rauch", "Einheiten im Rauch k�nnen weder angreifen noch reparieren. \nElektrizit�t besch�digt gegnerische Einheiten."},
	emerging = { "Vek treffen ein", "Feind erscheint im n�chste Zug. Kann blockiert werden."},
	critical = { "Kritisch", "Dieses Geb�ude ist wichtig f�r Missionsziele." },
	pylon = { "Energie Pylon", "Entfernter Energie Pylon verbindet Mechs auch unterirdisch mit dem Netz. Nicht besiedelt."},
	supervolcano = { "Super Vulkan", "Unzerst�rbarer Vulkan, der Bewegung und Projektile blockiert."},
	powered = { "Zivilgeb�ude", "Das Stromnetz wird besch�digt, wenn Strukturen besch�digt werden." },
	evacuated = { "Evakuiertes Geb�ude", "Keiner mehr hier, kann ruhig zerst�rt werden." },
	building_rubble = { "Bauschutt", "Kein besonderer Effekt." },
	mnt_rubble = {"Bergschutt", "Kein besonderer Effekt." },
	ice = {"Eis", "Wird bei Scahden zu Wasser. Muss zweimal getroffen werden."},
	acid_ice = {"Gefrorene S�ure", "Verwandelt sich in ein S�urefeld wenn es Schaden nimmt, , aber momentan ist es sicher."},
	lava_ice = {"Gefrorene Lava", "Wird bei Schaden zu Lava, aber momentan ist es sicher."},
	damaged_ice = {"Besch�digtes Eis", "Verwandelt sich in Wasser, wenn es zerst�rt wird. Ein Treffer wird es zerst�ren."},
	chasm = {"Abgrund", "Einheiten die darauf stehen werden\nwerden im Nichts versinken und get�tet."},
	ground = { "Boden", "Kein besonderer Effekt."},
	sand = { "Sand", "Wenn er besch�digt wird, wird er zu Rauch. \nEinheiten in Rauch k�nnen weder angreifen noch reparieren." },
	mountain = { "Berg", "Blockiert Bewegung und Geschosse. Besch�dige ihn zweimal, um ihn zu zerst�ren." },
	damaged_mountain = { "Besch�digter Berg", "Blockiert Bewegung und Geschosse. Ein Treffer wird ihn zerst�ren." },
	water = { "Wasser", "Einheiten k�nnen im Wasser nicht angreifen. Die meisten nicht fliegenden Feinde sterben im Wasser."},
	acid_water = { "S�ure", "Benimmt sich wie Wasser, aber verursacht S�ureschaden auf �berlebenden Einheiten."},
	lava = {"Lava", "Benimmt sich wie Wasser, verbrennt aber �berlebende Einheiten."},
	acid = { "S�urebad", "Die erste Einheit die hier steht wird mit S�ure behaftet."},
	frozen_acid = { "Gefrorene S�ure", "Niedrige Temperaturen haben die S�ure gefrieren lassen."},
	pod = {"Zeitkapsel", "Wird zerst�rt, wenn es vom Feind besch�digt oder zertrampelt wird. Sammle es mit einem Mech oder verteidige es bis zum R�ckzug der Vek."},
	ftl_pod = {"Merkw�rdige Kapsel", "Wird zerst�rt, wenn es vom Feind besch�digt oder zertrampelt wird. Sammle es mit einem Mech oder verteidige es bis zum R�ckzug der Vek."},
	ftl_button = {"Seltsames Objekt", "Du bist dir nicht sicher, was das sein k�nnte."},
	ftl_button_destroyed = {"Zerst�rtes Objekt", "Du bist dir nicht sicher, was das war, aber es ist jetzt weg."},
	frozen_powered = { "Gefrorenes Geb�ude", "Unbesiegbar wenn eingefroren. Jeder Schaden wird das Eis zerst�ren." },
	spawning = {"Kommt", "Vek wird hier im n�chsten Zug auftauchen. Jede Einheit, die dieses Feld blockiert, erh�lt einen Schaden."},
	high_tide = {"Flut","Dieses Feld wird zu Beginn der gegnerischen Runde zu Wasser."},
	air_strike = {"Luftangriff", "Bomben werden hier abgeworfen und t�ten sofort jede Einheit."},
	old_earth_mine = {"Alte Erdmine", "Jede Einheit, die auf diesem Feld stoppt, wird die Mine ausl�sen und dabei get�tet."},
	freeze_mine = {"Eismine", "Jede Einheit, die auf diesem Feld stoppt, wird eingefroren."},
	evacuation = {"Evakuieren", "Dieses Geb�ude wird evakuiert\nim n�chsten Zug."},
	seismic = {"Seismische Aktivit�t", "Dieses Feld wird zu Beginn des gegnerischen Spielzuges ein Abgrund."},
	lightning = {"Blitzschlag", "Ein Blitz wird hier einschlagen und jede Einheit t�ten."},
	falling_rock = {"Fallender Stein", "Ein Stein wird hier einschlagen und jede Einheit t�ten."},
	tentacle_lava = {"Tentakeln", "Die Einheit wird sterben und das Feld wird zu Lava."},
	volcano_lava = {"Lavastrom", "Das Feld wird zu Lava."},
	flying_rock = {"Vulkanischer Auswurf", "Ein Feuerball wird hier einschlagen und alles zerst�ren."},
	ice_storm = {"Eissturm", "Der Sturm bewirkt, dass alles eingefroren wird."},
	grassland = {"Wiese", "Das Bonusziel ist es, Gras in Sand zu verwandeln."},
	terraformed = {"Terraformiert", "Das Feld wurde als Teil deines Bonusziels terraformiert."},
	stasis = {"Stasis Bot", "Dieser Bot wird hochgefahren und tritt in den Kampf ein, wenn sein Schild besch�digt ist."},
	
	belt = {"F�rderband", "Dieses Feld dr�ckt jede Einheit in die Richtung, die auf dem Band markiert ist."},
	
	tele = {"Teleporter", "Beenden die Bewegung hier, um sich zum passenden Pad zu teleportieren. Tauscht Platz mit anderer Einheit."},
	
	supply_drop = { "Nachschub", "Sammle das mit einem Mech, um ALLE deine Einheiten zu heilen und ALLE Waffen mit begrenzter Nutzung wiederherzustellen." },	
}

local STATUS_TOOLTIPS = {
	flying = {"Fliegt", "Fliegende Einheiten k�nnen sich �ber jedes Feld bewegen."},
	hp = {"Belebende Sporen", "Der Soldat Psion liefert allen Vek +1 Gesundheit."},
	burrow = {"Gr�ber", "Dieser Vek wird sich nach einem oder mehreren Besch�digungen im Untergrund verstecken."},
	psionboss = { "�berlastet", "Diese Psion Abscheulichkeit verbessert alle Vek. Sie gewinnen +1 Gesundheit, Regeneration und explodieren beim Tod."},
	tentacle = { "Vom Hive erfasst", "Der Psion Tyrann f�gt allen verb�ndeten Einheiten in jedem Zug 1 Schaden zu."},
	armor_leader = {"Geh�rteter Panzer", "Der Psion versorgt alle Vek mit R�stung, wodurch der Schaden ankommender Waffen um 1 verringert wird. Alle anderen Sch�den (Sto�, Blockieren, Feuer usw.) bleiben davon unber�hrt."},
	armor = {"Nat�rliche R�stung", "Waffenschaden f�r diese Einheit wird um 1 verringert. Alle anderen Sch�den (Sto�en, Blockieren, Feuer usw.) sind davon nicht betroffen."},
	armor_degraded = {"Herabgesetzte R�stung", "S�ure deaktiviert momentan die Effekte von R�stung auf dieser Einheit."},
	regen = {"Regeneration", "Der Blutpsion heilt alle Vek um 1 Punkt in jedem Zug."},
	explode_leader = {"Explosiver Zerfall", "Der Explosions-Psion l�sst alle get�teten Vek explodieren, was wiederum den benachbarten Felder 1 Schaden zuf�gt."},
	explode = {"Explosiver Zerfall", "Explodiert beim Tod und f�gt benachbarten Feldern 1 Schaden zu."}, --was Innate Explosions
	arrow_0 = {"F�rderband", "Diese Einheit wird vom F�rderband in die markierte Richtung geschoben."},
	arrow_1 = {"F�rderband", "Diese Einheit wird vom F�rderband in die markierte Richtung geschoben."},
	arrow_2 = {"F�rderband", "Diese Einheit wird vom F�rderband in die markierte Richtung geschoben."},
	arrow_3 = {"F�rderband", "Diese Einheit wird vom F�rderband in die markierte Richtung geschoben."},
	tele_A = {"Teleporter", "Wenn eine andere Einheit das ROTE-Teleport-Pad verwendet, tauscht diese Einheit die Positionen mit ihr aus."},
	tele_B = {"Teleporter", "Wenn eine andere Einheit das BLAUE-Teleport-Pad verwendet, tauscht diese Einheit die Positionen mit ihr aus."},
	moving = {"Bonus verschieben", "+2 Bewegung f�r EINEN Zug."},
	grapple = {"Festgebunden", "Einheiten, die von Vek festgebunden wurden, k�nnen sich nicht bewegen, aber sie k�nnen trotzdem angreifen."},
	poweroff = {"Ohne Energie", "Einheiten ohne Energie sind inaktiv und k�nnen sich nicht bewegen oder angreifen."},
	massive = {"Massiv", "Massive Einheiten k�nnen im Wasser laufen, aber sie k�nnen nicht schie�en."},
	water = {"Steht im Wasser", "Waffen funktionieren nicht, wenn sie im Wasser stehen."},
	acid_water = { "Steht in S�ure", "Waffen funktionieren nicht und der Mech steht in korrodierender S�ure."},
	lava = { "Steht in Lava", "Waffen funktionieren nicht und der Mech brennt in der Lava."},
	fire = {"Feuer", "Brennende Einheiten erleiden zu Beginn jeden Zuges 1 Schaden."},
	forest = {"Auf Wald", "Feld brennt nach einem Angriff und verbrennt jede Einheit die darauf steht."},
	sand = {"Auf Sand", "Das Feld wird sich bei einem Schaden in Rauch verwandelt und verhindert, dass diese Einheit angreift."},
	ice = {"Auf Eis", "Wenn das Feld zweimal Schaden nimmt, wird es zu Wasser."},
	icecrack = {"Auf besch�digtem Eis", "Besch�digtes Eis wird zu Wasser, wenn es nochmal besch�digt wird."},
	acid = {"Korrodierende S�ure", "Waffenschaden gegen diese Einheit wird verdoppelt. Alle anderen Sch�den (Sto�, Blockieren, Feuer usw.) sind nicht betroffen."},
	spawnblock = {"Spawn blockieren", "Der Vek wird hier nicht erscheinen, aber diese Einheit wird 1 Schaden erleiden."},
	smoke = {"Rauch", "Einheiten im Rauch k�nnen weder angreifen noch reparieren."},
	electric_smoke = {"Elektrischer Rauch", "Einheiten in Rauch k�nnen weder angreifen noch reparieren. Elektrizit�t besch�digt gegnerische Einheiten."},
	shield = {"Energieschild", "Schilde blockieren den Schaden und alle negativen Effekte (Feuer, Frieren, S�ure, etc.). Nur direkter Schaden wird den Schild zerst�ren."},
	zoltan_shield = {"Zoltan Schild", "Wie ein normaler Schild, regeneriert sich jedoch zu Beginn von jedem Zug"},
	guard = {"Stabil", "Kann nicht durch einen Waffeneffekt bewegt werden (Sto�, Teleport, etc.)."},
	frozen = {"Gefroren", "Unbesiegbar, aber unf�hig sich zu bewegen oder anzugreifen. Jeder Schaden befreit die Einheit."},
	kickoff = {"Kickoff-Booster", "+2 Bewegung in diesem Zug."},
	shifty = {"Sidestep", "(Pilot Skill) Diese Einheit erh�lt nach dem Angreifen eine zus�tzliche Bewegung."},
	youthful = {"Treibend", "Diese Einheit erh�lt im ersten Zug jeder Mission +3 Bewegung."},
	doubleshot = {"Doppelschuss", "(Pilot Skill) Diese Einheit erh�lt eine Bonusaktion, weil sie sich nicht bewegt hat."}, 
	postmove = {"Schie�en und vergessen", "(Pilot Skill) Diese Einheit kann sich nach dem Schie�en bewegen."},
	fire_immune = {"Feuer Immunit�t", "Diese Einheit kann nicht brennen"},
	smoke_immune = {"Rauch-Immunit�t", "Einheit ist gegen Rauch immun"},
	shield_heal = {"Selbstreparierend", "Bei einer Besch�digung schirmt sich diese Einheit ab und bereitet sich auf die Heilung vor."},
	danger = {"Umweltgefahr", "The environment effect will affect this space next turn"},
	purple = {"Alpha-Einheit", "Alpha units are more powerful than their standard counterparts"},
	boss = {"Schwarmf�hrer", "Dies sind die m�chtigsten Vek. Sie sind immun gegen Wasser und sind schwieriger zu t�ten."},

}

local PilotSkills = {
	Disable_Immunity = PilotSkill("Evasion","Mech unaffected by Webbing and Smoke."),
	Extra_XP = PilotSkill("Experienced","Gain +2 bonus XP\nper kill."),
	Self_Shield = PilotSkill("Starting Shield","Mech starts every mission with a Shield."),
	Road_Runner = PilotSkill("Maneuverable","Mech can move through enemy units."),
	Shifty = PilotSkill("Sidestep","After attacking, gain 1 free tile movement."),
	Deploy_Anywhere = PilotSkill("Preemptive Strike", "Deploy anywhere on the map, damaging adjacent enemies."),
	Survive_Death = PilotSkill("Vek", "Normal Pilots cannot be equipped. Loses 25 XP when the unit is disabled."),
	Pain_Immunity = PilotSkill("Cauterize", "Fire heals instead of damaging Mech."),
	Power_Repair = PilotSkill("Frenzied Repair", "Push adjacent tiles when repairing."),
	Freeze_Walk = PilotSkill("Frozen Stance", "Stopping on any liquid tile freezes it, making it safe to stand on."),
	Armored = PilotSkill("Armored", "Mech gains Armored."),
	Flying = PilotSkill("Fliegt", "Mech gains Flying."),
	Double_Shot = PilotSkill("Doppelschuss", "Mech can act twice if it does not move."),
	Post_Move = PilotSkill("Schie�en und vergessen", "Move again after shooting."),
	Youth_Move = PilotSkill("Treibend", "Gain +3 Move on first turn of every mission."),
	Retaliation = PilotSkill("Retaliation", "Deal 1 damage to adjacent enemies after surviving damage."),
	TimeTravel = PilotSkill("Temporal Reset", "Gain 1 extra 'Reset Turn' every battle."),
	Mantis_Skill = PilotSkill("Mantis", "2 damage melee attack replaces Repair."),
	Rock_Skill = PilotSkill("Rockman", "+3 Health and\nImmune to Fire."),
	Zoltan_Skill = PilotSkill("Zoltan", "+1 Reactor Core.\nReduce Mech HP to 1.\nGain Shield every turn."),
}

function GetSkillInfo(skill)
	if skill == "" then return PilotSkill() end
	return PilotSkills[skill]
end

function GetTileTooltip(id)
	if TILE_TOOLTIPS[id] ~= nil then
		return TILE_TOOLTIPS[id]
	else
		return { id, "NOT FOUND"}
	end
end

function GetStatusTooltip(id)
	if STATUS_TOOLTIPS[id] ~= nil then
		return STATUS_TOOLTIPS[id]
	else
		return { id, "NOT FOUND"}
	end
end